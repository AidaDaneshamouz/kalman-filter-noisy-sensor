# Kalman Filtering for Noisy Sensor Measurements
Student Name: Aida Daneshamouz

Student ID: 403110047

University: Sharif University

## 1. Abstract
Sensor measurements are often affected by random noise, making it difficult to estimate the true position of a moving object accurately. This project implements a Kalman filter in Python to estimate the position and velocity of a moving object from noisy position measurements. The Kalman filter is implemented from scratch using NumPy and is compared with raw sensor measurements and a moving-average filter.

The simulated system uses a one-dimensional constant-velocity state-space model with random acceleration. The main experiment uses 300 time steps, a time interval of 0.1 seconds, an acceleration-noise standard deviation of 0.35, a measurement-noise standard deviation of 2.0, and a moving-average window of seven samples. Performance is evaluated using root mean square error (RMSE).

For the main experiment, the RMSE of the raw measurements is 2.0203 m, while the moving-average filter achieves 0.8004 m and the Kalman filter achieves 0.4452 m. A further noise-sensitivity experiment evaluates six measurement-noise levels, from 0.5 m to 5.0 m, with 20 independent simulations for each level. The Kalman filter produces the lowest mean position RMSE at every tested noise level. These results demonstrate that the Kalman filter can improve position estimation by combining noisy measurements with a model of the object's motion.

## 2. Introduction
Accurate sensor measurements are important in applications such as robotics, navigation, vehicle tracking, and motion estimation. However, real sensors are affected by measurement errors and random noise. Consequently, the measured position of an object may differ significantly from its true position.

A simple way to reduce measurement noise is to use a moving-average filter. This method smooths measurements by averaging nearby samples. Although it can reduce random fluctuations, it does not explicitly model the object's motion or estimate its velocity.

The Kalman filter provides another approach. It combines information from a mathematical model of the system with new sensor measurements. At each time step, it predicts the next state and then corrects that prediction using the latest measurement. The balance between the prediction and measurement depends on their estimated uncertainties.

In this project, a Kalman filter is implemented to estimate the position and velocity of a simulated moving object. Its performance is compared with raw measurements and a moving-average filter. The project also investigates how increasing measurement noise affects the accuracy of each method.

## 3. Project Objectives
The main objectives of this project are:

1. Simulate one-dimensional motion with random acceleration and noisy position measurements.

2. Implement a Kalman filter from scratch using NumPy.

3. Estimate both position and velocity from position measurements.

4. Implement a moving-average filter as a baseline method.

5. Compare raw measurements, moving-average estimates, and Kalman-filter estimates using RMSE.

6. Visualize the true position, noisy measurements, and filtered position estimates.

7. Examine the Kalman filter's velocity estimates.

8. Evaluate the performance of the three methods at different measurement-noise levels using 20 independent runs per level.

## 4. Theoretical Background
### 4.1 State-Space Model
The simulated object moves along a one-dimensional path. Its state contains position and velocity:

$$

\mathbf{x}_k =

\begin{bmatrix}

p_k\\\\

v_k

\end{bmatrix}

$$

where:

- $p_k$ is the position at time step $k$, measured in metres.

- $v_k$ is the velocity at time step $k$, measured in metres per second.

The time interval used in the notebook is:

$$

\Delta t = 0.1 \text{ s}

$$

The motion model is:

$$

p_k = p_{k-1} + \Delta t\\,v_{k-1}

+ \frac{1}{2}\Delta t^2 a_k

$$

$$

v_k = v_{k-1} + \Delta t\\,a_k

$$

where $a_k$ is a random acceleration disturbance.

The acceleration disturbance is sampled from a zero-mean Gaussian distribution with standard deviation:

$$

\sigma_a = 0.35

$$

The initial true state is:

$$

\mathbf{x}_0 =

\begin{bmatrix}

0\\\\

1.2

\end{bmatrix}

$$

Therefore, the simulated object begins at position 0 m with an initial velocity of 1.2 m/s.

The state-space transition equation is:

$$

\mathbf{x}*_k = F\mathbf{x}_*{k-1} + G a_k

$$

where the state-transition matrix is:

$$

F =

\begin{bmatrix}

1 & \Delta t\\\\

0 & 1

\end{bmatrix}

=

\begin{bmatrix}

1 & 0.1\\\\

0 & 1

\end{bmatrix}

$$

The acceleration-input matrix is:

$$

G =

\begin{bmatrix}

\frac{1}{2}\Delta t^2\\\\

\Delta t

\end{bmatrix}

=

\begin{bmatrix}

0.005\\\\

0.1

\end{bmatrix}

$$

These matrices describe how the previous position and velocity determine the next state.

### 4.2 Measurement Model
The simulated sensor measures position but does not directly measure velocity. The measurement equation is:

$$

z_k = H\mathbf{x}_k + r_k

$$

where:

$$

H =

\begin{bmatrix}

1 & 0

\end{bmatrix}

$$

and $r_k$ is the measurement noise.

The measurement noise is generated from a zero-mean Gaussian distribution:

$$

r_k \sim \mathcal{N}(0,\sigma_z^2)

$$

For the main experiment, the measurement-noise standard deviation is:

$$

\sigma_z = 2.0 \text{ m}

$$

Consequently, the measurement variance is:

$$

R = \sigma_z^2 = 4.0

$$

The simulated sensor readings are generated by adding random measurement noise to the true position.

### 4.3 Process-Noise Covariance
The process-noise covariance matrix represents uncertainty introduced by random acceleration. The notebook calculates it using:

$$

Q = \sigma_a^2 GG^T

$$

For $\sigma_a=0.35$ and $\Delta t=0.1$, the resulting matrix is:

$$

Q =

\begin{bmatrix}

3.0625\times10^{-6} & 6.125\times10^{-5}\\\\

6.125\times10^{-5} & 1.225\times10^{-3}

\end{bmatrix}

$$

This matrix describes how acceleration uncertainty contributes to uncertainty in position and velocity.

### 4.4 Kalman Filter Prediction
The Kalman filter maintains an estimated state and its covariance. At each time step, it first predicts the next state:

$$

\hat{\mathbf{x}}_{k|k-1}

= F\hat{\mathbf{x}}_{k-1|k-1}

$$

The covariance prediction is:

$$

P_{k|k-1}

= FP_{k-1|k-1}F^T+Q

$$

Here, $\hat{\mathbf{x}}*_{k|k-1}$ is the predicted state, and $P_*{k|k-1}$ is the predicted state-error covariance.

The prediction uses the motion model before considering the new sensor measurement.

### 4.5 Kalman Filter Update
After receiving a measurement, the filter calculates the innovation:

$$

y_k=z_k-H\hat{\mathbf{x}}_{k|k-1}

$$

The innovation represents the difference between the actual measurement and the predicted measurement.

Its covariance is:

$$

S_k=HP_{k|k-1}H^T+R

$$

The Kalman gain is calculated as:

$$

K_k=P_{k|k-1}H^TS_k^{-1}

$$

The predicted state is then corrected:

$$

\hat{\mathbf{x}}_{k|k}

=\hat{\mathbf{x}}_{k|k-1}+K_ky_k

$$

The covariance is updated using the Joseph form:

$$

P_{k|k} =

(I-K_kH)P_{k|k-1}(I-K_kH)^T

+K_kRK_k^T

$$

The Joseph form is used in the notebook to help preserve the numerical and symmetry properties of the covariance matrix.

The Kalman filter repeats these prediction and update steps for every measurement. Its output includes estimates of both position and velocity.

### 4.6 Moving-Average Filter
The moving-average filter provides a simpler baseline for comparison. It calculates each smoothed value by averaging seven nearby measurement samples.

For a window size $M=7$, the basic moving-average equation is:

$$

\bar{z}*_k=\frac{1}{M}\sum_*{i \in W_k}z_i

$$

where $W_k$ is the set of samples in the local window.

The notebook uses edge padding to maintain the original signal length, including at the beginning and end of the sequence.

Unlike the Kalman filter, the moving-average filter does not estimate velocity or explicitly incorporate a motion model. Its main purpose is to smooth fluctuations in the measurements.

### 4.7 Root Mean Square Error
The project evaluates position-estimation accuracy using root mean square error:

$$

RMSE =

\sqrt{\frac{1}{N}\sum_{k=1}^{N}

(\hat{p}_k-p_k)^2}

$$

where:

- $N$ is the number of time steps.

- $\hat{p}_k$ is the estimated position.

- $p_k$ is the true simulated position.

A lower RMSE indicates that the estimated positions are, on average, closer to the true positions under this error measure.

## 5. Methodology and Implementation
### 5.1 Software and Libraries
The project is implemented in Python using Jupyter Notebook. The libraries used are:

- **NumPy:** numerical calculations, matrices, random-number generation, and RMSE calculations.

- **Matplotlib:** plotting the true trajectory, measurements, estimates, and noise-sensitivity results.

The notebook records NumPy version 2.2.3. The random-number generator for the main simulation uses seed 42, while the sensitivity experiment uses seed 2026.

### 5.2 Simulation of Motion
The function `simulate_motion()` generates the true state and noisy sensor measurements.

The simulation uses:

| Parameter | Value |

|---|---:|

| Number of time steps | 300 |

| Time interval | 0.1 s |

| Total time span between first and last samples | 29.9 s |

| Initial position | 0 m |

| Initial velocity | 1.2 m/s |

| Acceleration-noise standard deviation | 0.35 |

| Main measurement-noise standard deviation | 2.0 m |

At every time step, the acceleration disturbance is sampled from a Gaussian distribution. The position and velocity are then updated using the motion equations. Finally, independent Gaussian measurement noise is added to the true position.

This produces two important data series: the true position and the noisy sensor measurements.

### 5.3 Kalman Filter Implementation
The function `kalman_filter()` implements the filtering algorithm without relying on a pre-built Kalman-filter package.

The initial state estimate is set to:

$$

\hat{\mathbf{x}}_0 =

\begin{bmatrix}

z_0\\\\

0

\end{bmatrix}

$$

Thus, the first measured position is used as the initial position estimate, while the initial velocity estimate is zero.

The initial covariance matrix is:

$$

P_0 =

\begin{bmatrix}

10 & 0\\\\

0 & 10

\end{bmatrix}

$$

The algorithm then performs prediction and measurement updates to produce position and velocity estimates for all 300 samples.

### 5.4 Moving-Average Implementation
The function `moving_average()` smooths the noisy measurements using a seven-sample window. Edge padding is applied before convolution so that the resulting filtered series has the same length as the original measurement series.

The smoothed series is then compared with the true position using RMSE.

### 5.5 Performance Comparison
The notebook evaluates three methods:

1. Raw sensor measurements.

2. Moving-average filtering.

3. Kalman filtering.

The same simulated true-position sequence is used when comparing these methods in the main experiment. The RMSE is calculated separately for each method.

The notebook also plots the estimated velocity from the Kalman filter alongside the true velocity.

### 5.6 Measurement-Noise Sensitivity Experiment
To evaluate how measurement noise affects performance, the notebook tests six measurement-noise standard deviations:

$$

\sigma_z \in \\{0.5,1.0,2.0,3.0,4.0,5.0\\}\text{ m}

$$

For each noise level, the notebook runs 20 independent simulations. Each simulation generates a new motion sequence and new noisy measurements. The three methods are evaluated against the corresponding true position.

The notebook calculates the mean RMSE across the 20 runs for each method and noise level.

The experiment therefore contains:

$$

6 \text{ noise levels}\times20 \text{ runs}

=120 \text{ simulations}

$$

Each simulation evaluates all three methods.

## 6. Experimental Results
### 6.1 True Position and Noisy Measurements
The first figure plots the true position against the noisy sensor measurements.

The simulated true position follows the motion model, while the measurements fluctuate around it because random noise is added to the true position. The difference between the two series demonstrates the difficulty of estimating the true trajectory from noisy measurements alone.

**Insert or retain the first figure from the simulation cell here.**

*\*Figure 1. True position and noisy sensor measurements over the simulated time interval.\**

### 6.2 Position-Estimation Comparison
The notebook compares the true position, raw measurements, moving-average estimates, and Kalman-filter estimates.

The measured position can deviate substantially from the true trajectory because of measurement noise. The moving-average filter smooths many of these fluctuations. The Kalman filter combines the measurements with the motion model to produce its own position estimate.

The main experiment produces the following results.

**Table 1. Position RMSE for the main simulation**

| Method | Position RMSE (m) |

|---|---:|

| Raw measurements | 2.0203 |

| Moving average, window size 7 | 0.8004 |

| Kalman filter | 0.4452 |

The Kalman filter achieves the lowest RMSE in this experiment.

Compared with the raw measurements, its RMSE decreases by approximately 78.0%. Compared with the moving-average filter, its RMSE decreases by approximately 44.4%.

These percentages are calculated from the RMSE values recorded in the notebook:

$$

\text{RMSE reduction} =

\frac{RMSE_{\text{baseline}}-RMSE_{\text{Kalman}}}

{RMSE_{\text{baseline}}}\times100\\%

$$

For the raw measurements:

$$

\frac{2.0203-0.4452}{2.0203}\times100\\%

\approx78.0\\%

$$

For the moving-average filter:

$$

\frac{0.8004-0.4452}{0.8004}\times100\\%

\approx44.4\\%

$$

The results indicate that the Kalman filter provides a more accurate position estimate than either comparison method for this particular simulated sequence.

**Insert or retain the position-estimation comparison figure from the notebook here.**

*\*Figure 2. Comparison of the true position, raw measurements, moving-average output, and Kalman-filter position estimate.\**

### 6.3 Velocity Estimation
The Kalman filter also estimates velocity even though the simulated sensor provides only position measurements.

The notebook plots the true velocity and estimated velocity together. This allows the performance of the velocity estimator to be assessed visually.

Because the velocity is not directly measured, its estimate depends on the motion model and on how successive position measurements inform the estimated state.

The notebook does not calculate a separate numerical velocity RMSE. Therefore, the velocity results are evaluated visually rather than through a reported numerical error metric.

**Insert or retain the velocity-estimation figure from the notebook here.**

*\*Figure 3. True velocity and velocity estimated by the Kalman filter.\**

### 6.4 Noise-Sensitivity Results
The second major experiment investigates how the three methods behave as the measurement-noise standard deviation increases.

The notebook records the following mean position RMSE values across 20 independent runs at each noise level.

**\*\*Table 2. Mean position RMSE across 20 runs per noise level\*\***

| Measurement-noise standard deviation (m) | Raw measurements RMSE (m) | Moving-average RMSE (m) | Kalman-filter RMSE (m) |

|---:|---:|---:|---:|

| 0.5 | 0.5028 | 0.1917 | 0.1883 |

| 1.0 | 0.9959 | 0.3714 | 0.2947 |

| 2.0 | 2.0006 | 0.7675 | 0.5289 |

| 3.0 | 3.0076 | 1.1536 | 0.7621 |

| 4.0 | 3.9615 | 1.5165 | 0.9670 |

| 5.0 | 4.9949 | 1.9025 | 1.1738 |

The results show three main patterns.

First, the RMSE of the raw measurements increases as measurement noise increases. This is expected because the raw measurements contain the added sensor noise without any filtering.

Second, the moving-average filter reduces RMSE relative to raw measurements at every tested noise level. Averaging nearby samples suppresses some of the random fluctuations.

Third, the Kalman filter has the lowest mean RMSE at all six noise levels. At the lowest noise level of 0.5 m, its mean RMSE is 0.1883 m, compared with 0.1917 m for the moving-average filter. At the highest noise level of 5.0 m, its mean RMSE is 1.1738 m, compared with 1.9025 m for the moving-average filter.

The difference between the two filtering methods becomes more pronounced at higher noise levels in this experiment.

**Insert or retain the noise-sensitivity plot from the notebook here.**

*\*Figure 4. Mean position RMSE versus measurement-noise standard deviation, calculated using 20 independent runs per setting.\**

## 7. Discussion
### 7.1 Effectiveness of the Kalman Filter
The main experiment shows that the Kalman filter reduces position-estimation error compared with both raw measurements and the moving-average filter.

The raw measurements have an RMSE of 2.0203 m, showing that the measurement noise has a substantial effect on the observed position. The moving-average filter reduces this error to 0.8004 m by smoothing nearby measurements. The Kalman filter reduces the RMSE further to 0.4452 m.

The results are consistent with the Kalman filter's design. Rather than processing each measurement in isolation, it predicts the object's next state using the motion model and then incorporates the new measurement. The filter's correction depends on the Kalman gain, which is influenced by the predicted uncertainty and measurement-noise covariance.

### 7.2 Comparison with the Moving-Average Filter
The moving-average filter is straightforward to implement and provides a useful baseline. It reduces measurement fluctuations without requiring a state-transition model or covariance matrices.

However, a moving average does not explicitly model position and velocity. The Kalman filter uses both the predicted state and the measurement to estimate the object's motion. This can help explain why the Kalman filter achieves lower RMSE in the experiments.

The results do not mean that a Kalman filter must always outperform every moving-average filter in every application. Performance depends on the motion model, noise characteristics, filter parameters, and averaging-window size. The results demonstrate superiority only under the conditions tested in this notebook.

### 7.3 Effect of Measurement Noise
The noise-sensitivity experiment shows that all three methods have increasing RMSE as measurement noise becomes larger.

For the raw measurements, mean RMSE rises from 0.5028 m at a noise standard deviation of 0.5 m to 4.9949 m at 5.0 m.

The moving-average filter reduces this error, but its mean RMSE also increases, reaching 1.9025 m at the highest tested noise level.

The Kalman filter's mean RMSE increases from 0.1883 m to 1.1738 m over the same range. Despite this increase, it remains the most accurate of the three methods at every tested noise level.

This indicates that the combination of a motion model and measurement updates provides an advantage for the simulated system, particularly when the measurements are noisy.

### 7.4 Estimating Velocity from Position Measurements
An important feature of this implementation is its ability to estimate velocity without direct velocity measurements.

The state-transition model links position and velocity. Changes in position measurements over time provide information about the object's motion, while the prediction step imposes the assumed relationship between position and velocity.

The velocity estimate is therefore a model-based estimate rather than a direct sensor reading. Its accuracy depends on the validity of the motion model, the process-noise assumptions, the measurement quality, and the initial state and covariance.

### 7.5 Role of the Noise Covariances
The process-noise covariance $Q$ represents uncertainty associated with random acceleration. The measurement-noise covariance $R$ represents uncertainty in the position sensor.

The notebook recalculates $R$ for each measurement-noise level used in the sensitivity experiment. As the assumed measurement noise increases, the measurement covariance increases as well.

These covariance values affect the Kalman gain and therefore influence how strongly the filter responds to measurements relative to its prediction.

The experiment illustrates the importance of representing measurement uncertainty appropriately. However, it does not establish that the selected process-noise model or its parameters are optimal for every motion scenario.

## 8. Limitations
Several limitations should be considered when interpreting the results.

### 8.1 Simulated Rather Than Real Sensor Data
The measurements are generated from a mathematical simulation. Real sensors may have systematic bias, time-varying noise, outliers, missing samples, or non-Gaussian errors. The results therefore demonstrate performance under the simulated conditions rather than guaranteeing the same performance with real hardware.

### 8.2 Assumptions About Motion
The filter uses a constant-velocity transition model with random acceleration represented as process noise. This is an approximation of the object's motion. Sudden changes in velocity or acceleration may be difficult to estimate accurately if the model does not represent them sufficiently well.

### 8.3 Initial-State Assumptions
The true initial velocity is 1.2 m/s, but the Kalman filter initializes its velocity estimate to zero. The initial covariance is set to a diagonal matrix with values of 10.

This means that the initial estimate does not use the true initial velocity, and the covariance expresses uncertainty about the initial state. Different initialization choices could affect early estimates.

### 8.4 Gaussian Noise Assumption
The simulation uses Gaussian random acceleration and Gaussian measurement noise with zero mean. This provides a controlled testing environment, but actual sensor errors may not follow these distributions.

### 8.5 Limited Parameter Testing
The notebook tests six measurement-noise levels, uses a fixed acceleration-noise standard deviation of 0.35, and applies a fixed moving-average window of seven samples.

It does not systematically optimize the moving-average window, compare alternative process-noise models, or evaluate different Kalman-filter initialization parameters.

### 8.6 Statistical Reporting
The noise-sensitivity experiment reports mean RMSE across 20 runs at each noise level. It does not report standard deviations, confidence intervals, or the individual RMSE values from all runs. These additional statistics could provide more information about variability across simulations.

### 8.7 Velocity Error Metric
The notebook plots the true and estimated velocities but does not calculate velocity RMSE. Therefore, the quantitative performance comparison in this report is based on position RMSE.

## 9. Conclusion
This project implemented a Kalman filter from scratch in Python to estimate the position and velocity of a moving object from noisy position measurements. The implementation uses a two-state model, a state-transition matrix, an acceleration-based process-noise covariance, and a measurement-noise covariance. A seven-sample moving-average filter was also implemented as a baseline.

In the main simulation, the raw measurements achieved a position RMSE of 2.0203 m, the moving-average filter achieved 0.8004 m, and the Kalman filter achieved 0.4452 m. The Kalman filter therefore produced the lowest position-estimation error in this experiment.

The noise-sensitivity experiment tested six measurement-noise standard deviations, from 0.5 m to 5.0 m, using 20 independent runs per setting. The Kalman filter had the lowest mean position RMSE at every tested noise level. At the highest noise level, its mean RMSE was 1.1738 m, compared with 1.9025 m for the moving-average filter and 4.9949 m for the raw measurements.

Overall, the results demonstrate that the Kalman filter is an effective method for reducing position-estimation error in the simulated system. Its use of a motion model, uncertainty estimates, and measurement updates gives it an advantage over the simple moving-average filter under the tested conditions. Nevertheless, its performance depends on the assumptions and parameters used, and further testing with real sensor data and additional evaluation metrics would be needed to assess its performance in practical applications.

## 10. References
The following references provide background on the Kalman-filter concepts used in this project. They are recommended theoretical references rather than sources cited directly by the notebook's code.

1. Kalman, R. E. (1960). “A New Approach to Linear Filtering and Prediction Problems.” *\*Journal of Basic Engineering\**, 82(1), 35–45.

2. Welch, G., and Bishop, G. “An Introduction to the Kalman Filter.” University of North Carolina at Chapel Hill.

3. Särkkä, S. (2013). *\*Bayesian Filtering and Smoothing\**. Cambridge University Press.

## 11. Reproducibility
The notebook contains the simulation, Kalman-filter implementation, moving-average filter, RMSE calculations, and plotting code required to reproduce the experiments.

The principal parameters are:

| Parameter | Value |

|---|---:|

| `DT` | 0.1 |

| `N_STEPS` | 300 |

| `SIGMA_ACCEL` | 0.35 |

| `SIGMA_MEAS` for the main experiment | 2.0 |

| `MOVING_AVERAGE_WINDOW` | 7 |

| `MEAS_NOISE_LEVELS` | [0.5, 1.0, 2.0, 3.0, 4.0, 5.0] |

| `N_RUNS` | 20 |

| Main simulation random seed | 42 |

| Sensitivity experiment random seed | 2026 |

To reproduce the reported results, run the notebook cells in order in an environment with NumPy and Matplotlib installed. The saved outputs in the supplied notebook contain the RMSE values reported in this document.
